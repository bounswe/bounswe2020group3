# Paperlayer System Manual (for customer deployment environment)
This document describes how to build, configure and deploy Paperlayer's web services. 

## Requirements
* [Docker](https://docs.docker.com/install/)
* [docker-compose](https://docs.docker.com/compose/install/)

## Configuration
Paperlayer's services are configured by using an environment file. 
There is an configuration file under paperlayer directory with the name `paperlayer_prod_env`.
It contains keys and values for postgresql image.
### Parameters
* **EMAIL_HOST_PASSWORD**: It is the password of our paperlayer gmail account. It is needed for verification mail.
* **AWS_ACCESS_KEYS**: We store our file and other images in AWS S3 bucket.
* **STREAM_API_KEYS**: We store activity stream data in [Stream](getstream.io) 3rd-party API. There are two group that are feed and timeline in the Stream dashboard
* **SENDGRID_API_KEY**: It is for verification mail system.

## How to Build & Deploy

### 1. Unzip the paperlayer.zip file and navigate to folder.
```bash
cd paperlayer
```

### 2. Build & run
```bash
docker-compose up -d --build
```

**Depends on the your system, it tooks a little long time.** It creates three images for backend, frontend and db.
After db image finished, it runs the paperlayer.sql scripts for loading all data to db.

Backend service is running at http://localhost:8000

You can reach all APIs from http://localhost:8000/swagger

Frontend service is running at http://localhost:5000


## Notes:

After registration, the verification mail will be sent to your email address.
You have to verify your account by clicking verification url.